#!/bin/bash
nohup npm run dev -- --host 0.0.0.0 --port 8501 > npm.log 2>&1 &
nohup python3.11 app.py > flask.log 2>&1 &
echo "Both processes have started!"

