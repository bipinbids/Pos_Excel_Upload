from flask import Flask, request, render_template, jsonify, session, redirect, url_for
import os
from werkzeug.utils import secure_filename
from groq import Groq
import base64
import json
import random
import time
import requests
import pandas as pd

app = Flask(__name__)
app.secret_key = 'your-secret-key-here'  # Required for session management

headers = {
  'Simphony-OrgShortName': '{{OrgShortCode}}',
  'Content-Type': 'application/json',
  'Authorization': 'Bearer eyJraWQiOiJlZTc5YmZhMy03NTRjLTRiYjQtYjExNS04YWZkOTE3NTEzMGUiLCJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiJ9.eyJpc3MiOiJodHRwczovL3d3dy5vcmFjbGUuY29tL2luZHVzdHJpZXMvaG9zcGl0YWxpdHkvZm9vZC1iZXZlcmFnZSIsInN1YiI6IjhjMWIwMTMyLThmMDQtNDU1Yi04NmJhLWE0ZjY1ZTE5OTkwMyIsImF1ZCI6IlVFOVRMbVV5WmpBeU1HTXdMVGRoWldVdE5ETmtOaTFpTURsaUxXTTNaR1U1WkdVNE1EWTNNUT09IiwiZXhwIjoxNzQ5MzEzOTM5LCJpYXQiOjE3NDgxMDQzMzksInRlbmFudCI6ImM0OWVkMmI3LWM5Y2QtNGUwYS04ZjE1LTE1NzQ3ZGU5N2ZkMiJ9.e_gO5ZLivqeBtZy3fgWRGMdi555HWE7ZoeAHxxgKTwn-wIqsTaIo-VrYZsS6k49YL0CDpY-l9Wla8njWptsLapv-hJFzMs94j7JeL2QidiSYRoYy3dazJx2pD0Yh_cW6pohXeGYYbGmjksvlGpDDuZKHstIZNoAhezTdpEF8PsMOsnbR730OXHpJU5k6AH_IDqdvkFAG4iDb2iOkx4lN28PTLsiNkNZ8xsqLxITHDJI5mQDlBZIoYw8DDuNBdXLDnbUhkEBSgLCZoBUuuT6Wv3orzQfDbYqYlB-KaCLDKV4niZ9jJEGNR9BIOYiyENqLy5vgFpLr8pwj7PAVVdd5Zs0-9kUjmtCqaEq4y-rk4aW5FHl1HsiWy3bEzcnMqPEO-GilZnsrFtAVMNIxn4BXp50cYrImFBt-G7AclcynIt3-tzkO9YJ9tPZeNdsTpktUI6wa5DBMgnFGninubQwDxP2ztL3DNG1X4WyNCrSipsz9LRNzDWQ79yOb62Bhupum'
}

# Configure upload folder and allowed extensions
UPLOAD_FOLDER = 'uploads'
ALLOWED_EXTENSIONS = {'png', 'jpg', 'jpeg', 'gif','xlsx'}
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

# Ensure the upload folder exists
if not os.path.exists(UPLOAD_FOLDER):
    os.makedirs(UPLOAD_FOLDER)

def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

@app.route('/')
def upload_page():
    return render_template('upload.html')

@app.route('/menu')
def menu_page():
    menu_data = session.get('menu_data')
    if menu_data is None:
        return redirect(url_for('upload_page'))
    slu_df = pd.read_csv('SLus_in_G_Home.csv')
    slu_names = slu_df['name'].dropna().tolist()
    major_group_df = pd.read_csv('Major_Groups_in_G_Home.csv')
    major_group_names = major_group_df['name'].dropna().tolist()
    family_group_df = pd.read_csv('Family_Groups_in_G_Home.csv')
    family_group_names = family_group_df['name'].dropna().tolist()
    barcode_df = pd.read_csv('Barcodes_in_G_Home.csv')
    barcode_list = [str(b) for b in barcode_df['barcode'].dropna().tolist()]
    menu_item_class_df = pd.read_csv('menuitemclasses_in_G_Home.csv')
    menu_item_class_names = menu_item_class_df['name'].dropna().astype(str).tolist()
    print_class_df = pd.read_csv('printclasses_in_G_Home.csv')
    print_class_names = print_class_df['name'].dropna().astype(str).tolist()
    tax_rate_df = pd.read_csv('taxrates_in_G_Home.csv')
    tax_rate_names = tax_rate_df['name'].dropna().astype(str).tolist()
    location_df = pd.read_csv('Locations_in_G_Home.csv')
    location_names = location_df['name'].dropna().astype(str).tolist()
    return render_template('menu.html', menu_data=menu_data, slu_names=slu_names, major_group_names=major_group_names, family_group_names=family_group_names, barcode_list=barcode_list, menu_item_class_names=menu_item_class_names, print_class_names=print_class_names, tax_rate_names=tax_rate_names, location_names=location_names)
    

@app.route('/upload', methods=['POST'])
def upload_image():
    if 'file' not in request.files:
        return jsonify({"error": "No file part"}), 400
    
    file = request.files['file']
    
    if file.filename == '':
        return jsonify({"error": "No selected file"}), 400
    
    if file and allowed_file(file.filename):
        filename = secure_filename(file.filename)
        filepath = os.path.join(app.config['UPLOAD_FOLDER'], filename)
        file.save(filepath)
        # Call the function to process the image
        result = menu_image_to_json_converter(filepath)
        # Clean up the uploaded file
        os.remove(filepath)
        # Store the result in session
        session['menu_data'] = result
        # Return success response
        return jsonify({"success": True})
    return jsonify({"error": "File type not allowed"}), 400

total_ids = []

def upload_menu_items_from_image(name, price, barcode, barcode_color, slu, slu_color, major_group, major_group_color, family_group, family_group_color, menu_item_class, print_class, discount=0, tax_rate=None, location=None):
    print('\nCurrently Processing:-\n',
          'Mneu_Item_Name:-', name,
          'Mneu_Item_Price:-', price,
          'Mneu_Item_Barcode:-', barcode,
          'Barcode_Color:-', barcode_color,
          'SLU:-', slu,
          'SLU_Color:-', slu_color,
          'Major_Group:-', major_group,
          'Major_Group_Color:-', major_group_color,
          'Family_Group:-', family_group,
          'Family_Group_Color:-', family_group_color,
          'Menu_Item_Class:-', menu_item_class,
          'Print_Class:-', print_class,
          'Mneu_Item_Discount:-', discount,
          'Tax_Rate:-', tax_rate,
          'Location:-', location, '\n')
    #return #comment this for the function to work
    '''
    Insert Menu item prices 
    Parameter:-
    name:- Name of the menu item
    price:- price of the menu item
    barcode:- barcode of the menu item
    discount:- discount of the menu item
    return value
    '''
    
    
    def get_next_number(id_,fetch_type):
            if fetch_type =='defSequenceNum':
                url = "https://mtu2-cnc.oraclemicros.com/config/sim/v1/menuitems/getmenuitemdefinitions"
                payload = json.dumps({
                  "include": "",
                  "searchCriteria": "where equals(menuItemMasterId,"+str(id_)+")",
                  "languages": ""
                })       
                response = requests.request("POST", url, headers=headers, data=payload)
                json_object = json.loads(response.text)
                items=json_object['items']
                df = pd.DataFrame(items)
                if len(df)>1:
                    return max(list(df['defSequenceNum']))+1
                else:
                    return 1
            
            elif fetch_type == 'objectNum':
                url = "https://mtu2-cnc.oraclemicros.com/config/sim/v1/menuitems/getmenuitemmasters"         
                payload = json.dumps({
                      
                      "limit":50000, 
                      "searchCriteria": "where equals(hierUnitId,"+str(id_)+")",
                      "languages": ""
                    })
                response = requests.request("POST", url, headers=headers, data=payload)
                json_object = json.loads(response.text)
                items=json_object['items']
                df = pd.DataFrame(items)         
                objectNums = list(df['objectNum'])
                objectNums_sorted = sorted(objectNums)
                for i in range(objectNums_sorted[0], objectNums_sorted[-1] + 1):
                    if i not in objectNums_sorted:
                        return i
                        break 
            
            elif fetch_type == 'barcode':
                url = "https://mtu2-cnc.oraclemicros.com/config/sim/v1/menuitems/getbarcodes"
                payload = json.dumps({
                  "hierUnitId": id_,
                  "offset": 0,
                  "limit": 50000,  
                })
                response = requests.request("POST", url, headers=headers, data=payload)
                json_object = json.loads(response.text)
                items=json_object['items']
                df = pd.DataFrame(items)         
                objectNums = list(df['objectNum'])
                objectNums_sorted = sorted(objectNums)
                for i in range(objectNums_sorted[0], objectNums_sorted[-1] + 1):
                    if i not in objectNums_sorted:
                        return i
                        break 
            
            elif fetch_type == 'discount':
                url = "https://mtu2-cnc.oraclemicros.com/config/sim/v1/sales/getDiscounts"
                payload = json.dumps({
                          "hierUnitId": id_,
                          "searchCriteria": "",
                          "languages": "",
                          "include": ""
                        })
                response = requests.request("POST", url, headers=headers, data=payload)
                json_object = json.loads(response.text)
                items=json_object['items']
                df = pd.DataFrame(items)         
                objectNums = list(df['objectNum'])
                objectNums_sorted = sorted(objectNums)
                for i in range(objectNums_sorted[0], objectNums_sorted[-1] + 1):
                    if i not in objectNums_sorted:
                        return i
                        break 
            
            elif fetch_type == 'SLU':
                url = "https://mtu2-cnc.oraclemicros.com/config/sim/v1/setup/getscreenlookups"
                payload = json.dumps({
                   "searchCriteria": "where equals(hierUnitId,"+str(id_)+")",
                  "languages": "",
                  "include": "",
                  "limit": 5000000
                })
                response = requests.request("POST", url, headers=headers, data=payload)
                json_object = json.loads(response.text)
                items=json_object['items']
                df = pd.DataFrame(items)   
                df=df.loc[df['type']==6]#searches only for type 6
                objectNums = list(df['objectNum'])
                objectNums_sorted = sorted(objectNums)
                for i in range(objectNums_sorted[0], objectNums_sorted[-1] + 1):
                    if i not in objectNums_sorted:
                        return i
                        break 
                        
            elif fetch_type == 'major_group': 
                url = "https://mtu2-cnc.oraclemicros.com/config/sim/v1/menuitems/getmajorgroups"
                payload = json.dumps({
                  "offset": 0,
                  "limit": 500000,
                  "orderBy": None,
                  "searchCriteria": "where equals(hierUnitId,"+str(id_)+")",
                  "languages": ""
                })
                response = requests.request("POST", url, headers=headers, data=payload)
                json_object = json.loads(response.text)
                items=json_object['items']
                df = pd.DataFrame(items)
                objectNums = list(df['objectNum'])
                objectNums_sorted = sorted(objectNums)
                for i in range(objectNums_sorted[0], objectNums_sorted[-1] + 1):
                    if i not in objectNums_sorted:
                        return i
                        break

            elif fetch_type == 'family_group':
                url = "https://mtu2-cnc.oraclemicros.com/config/sim/v1/menuitems/getfamilygroups"
                payload = json.dumps({
                  "offset": 0,
                  "limit": 500000,
                  "orderBy": None,
                  "searchCriteria": "where equals(hierUnitId,"+str(id_)+")",
                  "languages": ""
                })
                response = requests.request("POST", url, headers=headers, data=payload)
                json_object = json.loads(response.text)
                items=json_object['items']
                df = pd.DataFrame(items)
                objectNums = list(df['objectNum'])
                objectNums_sorted = sorted(objectNums)
                for i in range(objectNums_sorted[0], objectNums_sorted[-1] + 1):
                    if i not in objectNums_sorted:
                        return i
                        break 
                
    def insert_menu_item_master(name,major_group_objnum,family_group_objnum,hierUnitId=30215): 
        #requirement name
        url = "https://mtu2-cnc.oraclemicros.com/config/sim/v1/menuitems/menuItemmasters"
        fetch_type= 'objectNum'
        id_= hierUnitId
        payload = json.dumps({
          "hierUnitId": hierUnitId,
          "optionsExt": {
            "disableEditByWSEditMenuItem": True
          },
          "objectNum": get_next_number(id_,fetch_type),
          "majorGroupObjectNum":major_group_objnum,
          "familyGroupObjectNum":family_group_objnum,
          "name": {
            "en-US": name
          }
        })
        response = requests.request("POST", url, headers=headers, data=payload)
        return json.loads(response.text)

    def insert_menu_item_definition(name,menuItemMasterObjNum,menuItemMasterId,slu_objnum,menu_item_classObj,print_classObj,hierUnitId=30215):
        url = "https://mtu2-cnc.oraclemicros.com/config/sim/v1/menuitems/menuItemdefinitions"
        fetch_type='defSequenceNum'
        id_= hierUnitId
        payload = json.dumps({
          "hierunitid": hierUnitId,
          "menuItemMasterObjNum": menuItemMasterObjNum,
          "menuItemMasterId": menuItemMasterId,
          "defSequenceNum": get_next_number(id_,fetch_type),
          "firstName": {
            "en-US": name
          },
          "menuItemClassObjNum": menu_item_classObj,
          "printClassObjNum": print_classObj,
          "mainLevel": "11111111",
          "subLevel": "11111111",
          "quantity": 1,
          "slu1ObjNum":slu_objnum
        })
        response = requests.request("POST", url, headers=headers, data=payload) 
        return json.loads(response.text)

    def menu_price_insertion(menuItemDefinitionSequenceNum,menuItemMasterObjNum,menuItemMasterId,menuItemDefinitionId,price,hierUnitId=30215):
        url = "https://mtu2-cnc.oraclemicros.com/config/sim/v1/menuitems/menuItemPrices"
        payload = json.dumps({
          "hierUnitId": hierUnitId,
          "menuItemDefinitionId": menuItemDefinitionId,
          "priceSequenceNum": 1,
          "menuItemMasterId": menuItemMasterId,
          "menuItemMasterObjNum": menuItemMasterObjNum,
          
          "menuItemDefinitionSequenceNum": menuItemDefinitionSequenceNum,
          
          "activeOnMenuLevel": 0,
          "prepCost": 0,
          "price": price,
          "options": "00000000"
        })     
        response = requests.request("POST", url, headers=headers, data=payload)
        return json.loads(response.text)
        
    def menu_barcode_insertion(menuItemMasterObjNum,barcode,hierUnitId=30215):
        fetch_type= 'barcode'
        id_= hierUnitId
        url = "https://mtu2-cnc.oraclemicros.com/config/sim/v1/menuitems/barcodes"
        payload = json.dumps({
          "hierUnitId": hierUnitId,
          "barcode": barcode,
          "objectNum": get_next_number(id_,fetch_type),
          "masterObjNum":menuItemMasterObjNum
        })
        response = requests.request("POST", url, headers=headers, data=payload)
        return json.loads(response.text)
        
    def menu_discount_insertion(name, discount, hierUnitId=30215):
        discount=discount/100
        url = "https://mtu2-cnc.oraclemicros.com/config/sim/v1/sales/discounts"
        id_ = hierUnitId
        fetch_type = 'discount'
        payload = json.dumps({
            "hierUnitId": hierUnitId,
            "objectNum": get_next_number(id_, fetch_type),
            "name": {
                "en-US": name
            },
            "percent": discount,  # The discount is now always in percentage form
            "activationType": 0,
            "minAmount": 0,
            "condimentDiscountability": 0,
            "enabled": True,
            "options": "00000000000000000000000000000000000000000000000000000000",
            "rvcType": "11111111111111111111111111111111",
            "transDefaultMainLevel": False,
            "mainLevelPopup": 0,
            "transDefaultSubLevel": False,
            "subLevelPopup": 0,
            "sluObjNum": None,
            "sluName": None,
            "nlu": None,
            "exclusivity": {
                "transaction": "11111111111111111111111111111111",
                "item": "11111111111111111111111111111111"
            },
            "dscItmzr": "000000000000000"
        })
        
        response = requests.request("POST", url, headers=headers, data=payload)
        return json.loads(response.text)
        
    def menu_slu_insertion(name,hierUnitId=30215):
        fetch_type='SLU'
        url = "https://mtu2-cnc.oraclemicros.com/config/sim/v1/setup/screenlookups"
        payload = json.dumps({
          "objectNum": get_next_number(hierUnitId,fetch_type),
          "hierUnitId": hierUnitId,
          "name": {
            "en-US": name
          },
          "type": 6,
          "deviceType": 1
        })
        response = requests.request("POST", url, headers=headers, data=payload)
        return json.loads(response.text)
        
    def get_slu_objnumber(slu,hierUnitId=30215):
        url = "https://mtu2-cnc.oraclemicros.com/config/sim/v1/setup/getscreenlookups"
        payload = json.dumps({
          "offset": 0,
          "limit": 500000,
          "include":"objectNum",
          "orderBy": None,
          "searchCriteria": "where (equals("+"hierUnitId,"+str(hierUnitId)+")) and (equals(name,'"+slu+"'))",
          "languages": ""
        })
        response = requests.request("POST", url, headers=headers, data=payload)
        json_object = json.loads(response.text)
        items=json_object['items']
        df = pd.DataFrame(items)
        if len(df):
            slu_objnum=int(df.iloc[0, 0])
            return slu_objnum
        else:
            print('There was an error here')
        
    def menu_major_group_insertion(name,hierUnitId=30215):
        fetch_type= 'major_group'
        id_= hierUnitId
        url = "https://mtu2-cnc.oraclemicros.com/config/sim/v1/menuitems/majorgroups"
        payload = json.dumps({
          "hierUnitId": hierUnitId,
          "objectNum": get_next_number(id_,fetch_type),
          "name": {
            "en-US": name
          }
        })
        response = requests.request("POST", url, headers=headers, data=payload)
        return json.loads(response.text)
        
    def get_major_group_objnumber(major_group,hierUnitId=30215):
        url = "https://mtu2-cnc.oraclemicros.com/config/sim/v1/menuitems/getmajorgroups"
        payload = json.dumps({
          "offset": 0,
          "limit": 500000,
          "include":"objectNum",
          "orderBy": None,
          "searchCriteria": "where (equals("+"hierUnitId,"+str(hierUnitId)+")) and (equals(name,'"+major_group+"'))",
          "languages": ""
        })
        response = requests.request("POST", url, headers=headers, data=payload)
        json_object = json.loads(response.text)
        items=json_object['items']
        df = pd.DataFrame(items)
        if len(df):
            major_group_objnum=int(df.iloc[0, 0])
            return major_group_objnum
        else:
            print('There was an error here')
            
    
    def menu_family_group_insertion(name,hierUnitId=30215):
        fetch_type= 'family_group'
        id_= hierUnitId
        url = "https://mtu2-cnc.oraclemicros.com/config/sim/v1/menuitems/familygroups"
        payload = json.dumps({
          "hierUnitId": hierUnitId,
          "objectNum": get_next_number(id_,fetch_type),
          "name": {
            "en-US": name
          }
        })
        response = requests.request("POST", url, headers=headers, data=payload)
        return json.loads(response.text)
        
    def get_family_group_objnumber(family_group,hierUnitId=30215):
        url = "https://mtu2-cnc.oraclemicros.com/config/sim/v1/menuitems/getfamilygroups"
        payload = json.dumps({
          "offset": 0,
          "limit": 500000,
          "include":"objectNum",
          "orderBy": None,
          "searchCriteria": "where (equals("+"hierUnitId,"+str(hierUnitId)+")) and (equals(name,'"+family_group+"'))",
          "languages": ""
        })
        response = requests.request("POST", url, headers=headers, data=payload)
        json_object = json.loads(response.text)
        items=json_object['items']
        df = pd.DataFrame(items)
        if len(df):
            family_group_objnum=int(df.iloc[0, 0])
            return family_group_objnum
        else:
            print('There was an error here')
            
    def get_menu_item_class_objnumber(menu_item_class,hierUnitId=30215):
        url = "https://mtu2-cnc.oraclemicros.com/config/sim/v1/menuitems/getmenuitemclasses"
        payload = json.dumps({
          "offset": 0,
          "limit": 500000,
          "include":"objectNum",
          "orderBy": None,
          "searchCriteria": "where (equals("+"hierUnitId,"+str(hierUnitId)+")) and (equals(name,'"+menu_item_class+"'))",
          "languages": ""
        })
        response = requests.request("POST", url, headers=headers, data=payload)
        json_object = json.loads(response.text)
        items=json_object['items']
        df = pd.DataFrame(items)
        if len(df):
            menu_item_class_objnum=int(df.iloc[0, 0])
            return menu_item_class_objnum
        else:
            print('There was an error here')
            
    def get_menu_item_class_objnumber(menu_item_class,hierUnitId=30215):
        url = "https://mtu2-cnc.oraclemicros.com/config/sim/v1/menuitems/getmenuitemclasses"
        payload = json.dumps({
          "offset": 0,
          "limit": 500000,
          "include":"objectNum",
          "orderBy": None,
          "searchCriteria": "where (equals("+"hierUnitId,"+str(hierUnitId)+")) and (equals(name,'"+menu_item_class+"'))",
          "languages": ""
        })
        response = requests.request("POST", url, headers=headers, data=payload)
        json_object = json.loads(response.text)
        items=json_object['items']
        df = pd.DataFrame(items)
        if len(df):
            menu_item_class_objnum=int(df.iloc[0, 0])
            return menu_item_class_objnum
        else:
            print('There was an error here')
            
    def get_print_class_objnumber(print_class,hierUnitId=30215):
        url = "https://mtu2-cnc.oraclemicros.com/config/sim/v1/devices/getprinterclasses"
        payload = json.dumps({
          "offset": 0,
          "limit": 500000,
          "include":"objectNum",
          "orderBy": None,
          "searchCriteria": "where (equals("+"hierUnitId,"+str(hierUnitId)+")) and (equals(name,'"+print_class+"'))",
          "languages": ""
        })
        response = requests.request("POST", url, headers=headers, data=payload)
        json_object = json.loads(response.text)
        items=json_object['items']
        df = pd.DataFrame(items)
        if len(df):
            print_class_objnum=int(df.iloc[0, 0])
            return print_class_objnum
        else:
            print('There was an error here')
    
    if slu_color=="Blue":
        slu_r=menu_slu_insertion(slu)
        print('\n','SluObjnumber:-',slu_r['objectNum'],'\n')
        slu_objnum = get_slu_objnumber(slu)
    else:
        slu_r={}
        slu_r['objectNum']=0
        slu_objnum = get_slu_objnumber(slu)
        print('\n','SLU Discovered with objnum:-',slu_objnum,'\n')
    
    if major_group_color=="Blue":
        majorgroup_r=menu_major_group_insertion(major_group)
        print('\n','MajorGroupObjnumber:-',majorgroup_r['objectNum'],'\n')
        major_group_objnum = get_major_group_objnumber(major_group)
    else:
        majorgroup_r={}
        majorgroup_r['objectNum']=0
        major_group_objnum = get_major_group_objnumber(major_group)
        print('\n','Major Group Discovered with objnum:-',major_group_objnum,'\n')
        
    if family_group_color=="Blue":
        familygroup_r=menu_family_group_insertion(family_group)
        print('\n','FamilyGroupObjnumber:-',familygroup_r['objectNum'],'\n')
        family_group_objnum =get_family_group_objnumber(family_group)
    else:
        familygroup_r={}
        familygroup_r['objectNum']=0
        family_group_objnum =get_family_group_objnumber(family_group)
        print('\n','Family Group Discovered with objnum:-',family_group_objnum,'\n')
        
    menu_item_classObj= get_menu_item_class_objnumber(menu_item_class)
    print_classObj= get_print_class_objnumber(print_class)
    print('\n','Menu Item Class Discovered with objnum:-',menu_item_classObj,'\n')
    print('\n','Print Class Discovered with objnum:-',print_classObj,'\n')
    
    master_r=insert_menu_item_master(name,major_group_objnum,family_group_objnum)
    print('\n','MenuItemMasterId:-',master_r['menuItemMasterId'])
    
    menuItemMasterObjNum = master_r['objectNum']
    menuItemMasterId = master_r['menuItemMasterId']
    # Save the original master object number for UI display
    original_menuItemMasterObjNum = menuItemMasterObjNum
    definition_r = insert_menu_item_definition(name, menuItemMasterObjNum, menuItemMasterId, slu_objnum, menu_item_classObj, print_classObj)
    print('\n','MenuItemDefinitionId:-',definition_r['menuItemDefinitionId'])
    menuItemDefinitionSequenceNum = definition_r['defSequenceNum']
    # These may be overwritten, but we want to keep the original for display
    menuItemMasterObjNum = definition_r['menuItemMasterObjNum']
    menuItemMasterId = definition_r['menuItemMasterId']
    menuItemDefinitionId = definition_r['menuItemDefinitionId']
    price_r = menu_price_insertion(menuItemDefinitionSequenceNum, menuItemMasterObjNum, menuItemMasterId, menuItemDefinitionId, price)
    print('\n','MenuItemPriceId:-',price_r['menuItemPriceId'])
    
    barcode_r=menu_barcode_insertion(menuItemMasterObjNum,barcode)
    print('\n','BarcodeObjnumber:-',barcode_r['objectNum'])
    
    discount_name= name + ' Discount'
    discount_r=menu_discount_insertion(discount_name,discount)
    print('\n','DiscountObjnumber:-',discount_r['objectNum'],'\n')
    
    
    
    r= {}
    r['name']=name
    r['price']=price
    r['random_number_1'] = master_r['menuItemMasterId']
    r['random_number_2'] = definition_r['menuItemDefinitionId']
    r['random_number_3'] = price_r['menuItemPriceId']
    r['random_number_4'] = barcode_r['objectNum']
    r['random_number_5'] = discount_r['objectNum']
    r['random_number_6']= slu_r['objectNum']
    r['random_number_7']= majorgroup_r['objectNum']
    r['random_number_8']= familygroup_r['objectNum']
    r['random_number_9'] = original_menuItemMasterObjNum
    
    return r
    
    
def delete_menu_item_master(menuItemMasterId):
    url = "https://mtu2-cnc.oraclemicros.com/config/sim/v1/menuitems/deletemenuItemmasters"
    payload = json.dumps({
      "menuItemMasterId": menuItemMasterId
    })
    response = requests.request("POST", url, headers=headers, data=payload)
    return response
          
def delete_menu_item_definition(menuItemDefinitionID,HierUnitId=30215):
    url = "https://mtu2-cnc.oraclemicros.com/config/sim/v1/menuitems/deletemenuItemdefinitions"
    payload = json.dumps({
      "HierUnitId": HierUnitId,
      "menuItemDefinitionID": menuItemDefinitionID
    })
    response = requests.request("POST", url, headers=headers, data=payload)
    return response  

def delete_menu_item_price(menuItemPriceId):
    url = "https://mtu2-cnc.oraclemicros.com/config/sim/v1/menuitems/deletemenuItemPrices"
    payload = json.dumps({
        'menuItemPriceId':menuItemPriceId
    })
    response = requests.request("POST", url, headers=headers, data=payload)
    return response
    
def delete_menu_item_barcode(objectNum,HierUnitId=30215):
    url = "https://mtu2-cnc.oraclemicros.com/config/sim/v1/menuitems/deleteBarcodes"
    payload = json.dumps({
      "hierUnitId": HierUnitId,
      "objectNum": objectNum
    })    
    response = requests.request("POST", url, headers=headers, data=payload)
    return response
    
def delete_menu_item_discount(objectNum,HierUnitId=30215):
    url = "https://mtu2-cnc.oraclemicros.com/config/sim/v1/sales/deletediscounts"
    payload = json.dumps({
      "objectNum": objectNum,
      "hierUnitId": HierUnitId
    })
    response = requests.request("POST", url, headers=headers, data=payload)
    return response

def delete_menu_item_slu(objectNum,HierUnitId=30215):
    url = "https://mtu2-cnc.oraclemicros.com/config/sim/v2/setup/deleteScreenLookups"
    payload = json.dumps({
      "objectNum": objectNum,
      "hierUnitId": HierUnitId,
      "type": 6
    })
    response = requests.request("POST", url, headers=headers, data=payload)
    return response

def delete_menu_item_majorgroup(objectNum,HierUnitId=30215):
    url = "https://mtu2-cnc.oraclemicros.com/config/sim/v1/menuitems/deletemajorgroups"
    payload = json.dumps({
          "objectNum": objectNum,
          "hierUnitId": HierUnitId
        })
    response = requests.request("POST", url, headers=headers, data=payload)
    return response
    
def delete_menu_item_familygroup(objectNum,HierUnitId=30215):
    url = "https://mtu2-cnc.oraclemicros.com/config/sim/v1/menuitems/deletefamilygroups"
    payload = json.dumps({
          "objectNum": objectNum,
          "hierUnitId": HierUnitId
        })
    response = requests.request("POST", url, headers=headers, data=payload)
    return response




def delete_menu_items(total_ids):
    success_count=0
    #print('\ntotal_ids at the start is',total_ids)
    for i in range(len(total_ids)):
        menuItemfamilygroup_objnum=total_ids[i]['random_number_8']
        menuItemmajorgroup_objnum=total_ids[i]['random_number_7']
        menuItemSLU_objnum=total_ids[i]['random_number_6']
        menuItemDiscount_objnum=total_ids[i]['random_number_5']
        menuItemBarcode_objnum=total_ids[i]['random_number_4']    
        menuItemPriceId=total_ids[i]['random_number_3']
        menuItemDefinitionID=total_ids[i]['random_number_2']
        menuItemMasterId=total_ids[i]['random_number_1']
        
        if menuItemfamilygroup_objnum!=0:
            print('familygroup_objnum is',menuItemfamilygroup_objnum)
            response_familygroup=delete_menu_item_familygroup(menuItemfamilygroup_objnum)
            if response_familygroup.status_code==200:
                print('Family Group deletion worked perfectly\n')
                total_ids[i]['random_number_8'] = 0
        
        if menuItemmajorgroup_objnum!=0:
            print('majorgroup_objnum is',menuItemmajorgroup_objnum)
            response_majorgroup=delete_menu_item_majorgroup(menuItemmajorgroup_objnum)
            if response_majorgroup.status_code==200:
                print('Major Group deletion worked perfectly\n')
                total_ids[i]['random_number_7'] = 0
            
        if menuItemSLU_objnum!=0:
            print('slu_objnum is',menuItemSLU_objnum)
            response_slu=delete_menu_item_slu(menuItemSLU_objnum)
            if response_slu.status_code==200:
                print('SLU deletion worked perfectly\n')
                total_ids[i]['random_number_6'] = 0
            
        print('menuItemDiscount_objnum is',menuItemDiscount_objnum)
        response_discount=delete_menu_item_discount(menuItemDiscount_objnum)
        if response_discount.status_code==200:
            print('Discount deletion worked perfectly\n')
            total_ids[i]['random_number_5'] = 0
        
        print('menuItemBarcode_objnum is',menuItemBarcode_objnum)
        response_barcode=delete_menu_item_barcode(menuItemBarcode_objnum)
        if response_barcode.status_code==200:
            print('Barcode deletion worked perfectly\n')
            total_ids[i]['random_number_4'] = 0
            
        response_price=delete_menu_item_price(menuItemPriceId)
        if response_price.status_code==200:
            total_ids[i]['random_number_3'] = 0
        
        response_def=delete_menu_item_definition(menuItemDefinitionID)
        if response_def.status_code==200:
            total_ids[i]['random_number_2'] = 0
        
        response_master=delete_menu_item_master(menuItemMasterId)
        if response_master.status_code==200:
            total_ids[i]['random_number_1'] = 0
            
        if response_discount.status_code==200 and response_barcode.status_code==200 and response_price.status_code==200 and response_def.status_code==200 and response_master.status_code==200:
            success_count+=1
        else:
            print('There was an error in the deletion operation')
    
    if success_count == len(total_ids):
        total_ids=[]
    #print('total_ids now is',total_ids)
    return total_ids

@app.route('/delete-items', methods=['POST'])
def delete_items():
    global total_ids
    # Simulate processing time for each item
    time.sleep(1)
    updated_ids = delete_menu_items(total_ids)
    total_ids = updated_ids
    return jsonify({"success": True, "updated_items": updated_ids})

@app.route('/processed-items')
def get_processed_items():
    global total_ids
    return jsonify(total_ids)

@app.route('/process-item', methods=['POST'])
def process_item():
    data = request.json
    name = data.get('name')
    price = data.get('price')
    barcode = data.get('barcode')
    barcode_color = data.get('barcodeColor')
    slu = data.get('slu')
    slu_color = data.get('sluColor')
    major_group = data.get('majorGroup')
    major_group_color = data.get('majorGroupColor')
    family_group = data.get('familyGroup')
    family_group_color = data.get('familyGroupColor')
    menu_item_class = data.get('menuItemClass')
    print_class = data.get('printClass')
    tax_rate = data.get('taxRate')
    location = data.get('location')
    if name is None or price is None or barcode is None or slu is None or slu_color is None or major_group is None or major_group_color is None or family_group is None or family_group_color is None:
        return jsonify({"error": "Missing Input"}), 400
    result = upload_menu_items_from_image(name, price, barcode, barcode_color, slu, slu_color, major_group, major_group_color, family_group, family_group_color, menu_item_class, print_class, tax_rate=tax_rate, location=location)
    total_ids.append(result)
    return jsonify(result)

def menu_image_to_json_converter(image_path):
    df = pd.read_excel(image_path)
    menu_items_list = df.rename(
        columns={
            'Discount': 'discount',
            'Barcode': 'barcode',
            'Name': 'name',
            'Price': 'price',
            'SLU': 'slu',
            'Major Group': 'major_group',
            'Family Group': 'family_group',
            'Menu Item Class': 'menu_item_class',
            'Print Class': 'print_class',
            'Tax Rate': 'tax_rate',
            'Location': 'location'
        }
    ).to_dict(orient='records')
    final_json_output = {"menu_items": menu_items_list}
    return final_json_output

if __name__ == '__main__':
    app.run(debug=True)